import java.util.Scanner;
public class MinsToYearsDays {
	public static void main(String[] args){
        Scanner input = new Scanner(System.in);
       
        System.out.print("Enter the number of minutes: ");
        final int minutes = input.nextInt();
        System.out.print(minutes + " minutes is approximately " + minutes/525600 + " years and " + (int)((minutes%525600.0)*0.00069444444) + " days");
    }
}
