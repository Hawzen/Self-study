import java.util.Scanner;

public class BMI {
	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);

		System.out.print("Enter weight in pounds: ");
		double kg = (input.nextDouble() * 0.45359237);

		System.out.print("Enter height in inches: ");
		double m = (input.nextDouble() * 0.0254);

		System.out.print("BMI is " + (kg/(Math.pow(m, 2))));

	}
}
