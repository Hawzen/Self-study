public class TestMyInteger {
	public static void main(String[] args) {
		MyInteger positivePolarAttractorAlpha= new MyInteger(5);
		MyInteger positivePolarAttractorOmega= new MyInteger(24);
		
		positivePolarAttractorAlpha.isEven();
		positivePolarAttractorAlpha.isPrime();
		positivePolarAttractorOmega.isOdd();
		positivePolarAttractorAlpha.equals(positivePolarAttractorOmega);
		positivePolarAttractorAlpha.equals(5);
		positivePolarAttractorAlpha.add(positivePolarAttractorOmega);
		positivePolarAttractorOmega.sub(positivePolarAttractorAlpha);
		positivePolarAttractorAlpha.mul(positivePolarAttractorOmega);
		positivePolarAttractorOmega.div(positivePolarAttractorAlpha);
		MyInteger.isPrime(15);
		MyInteger.isOdd(45);
		}
}
