
public class MyInteger {
	private int value;
	public MyInteger(){
		this(0);
	}
	public MyInteger(int value){
		this.value = value;
	}
	public void setValue(int v) {value=v;}
	public int getValue() {return value;}
	
	//value methods
	public boolean isEven() {
		return value % 2 == 0 ;
	}
	public boolean isOdd() {
		return !(value % 2==0);
	}
	public boolean isPrime(){
		for(int i=1 ; i<value ; i++) {
			if(value % i==0) {
				return true;
			}
		}
		return false;
	}
	
	//Static methods
	public static boolean isEven(int value) {
		return value % 2 == 0 ;
	}
	public static boolean isOdd(int value) {
		return !(value % 2==0);
	}
	public static boolean isPrime(int value){
		for(int i=1 ; i<value ; i++) {
			if(value % i==0) {
				return true;
			}
		}
		return false;
	}
	
	//MyInteger methods
	public static boolean isEven(MyInteger value) {
		return value.value % 2 == 0 ;
	}
	public boolean isOdd(MyInteger value) {
		return !(value.value % 2==0);
	}
	public static boolean isPrime(MyInteger value){
		for(int i=1 ; i<value.value ; i++) {
			if(value.value % i==0) {
				return true;
			}
		}
		return false;
	}
	
	//add sub mult div methods, returns a new object
	public MyInteger add(MyInteger n) {
		return new MyInteger(this.value + n.value);
	}
	
	public MyInteger sub(MyInteger n) {
		return new MyInteger(this.value - n.value);
	}
	public MyInteger mul(MyInteger n) {
		return new MyInteger(this.value * n.value);
	}
	public MyInteger div(MyInteger n) {
		if (n.value==0) {return null;}
		return new MyInteger(this.value / n.value);
		
	//equals methods
	}
	public boolean equals(int n){
		return this.value==n;
	}
	public boolean equals(MyInteger n) {
		return this.value==n.value;
	}
	
}
