import java.util.Scanner; 
public class Pyramid {
	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
		System.out.print("Enter the number of lines: ");
		int slices = input.nextInt();
		
		for(int i=1; i <= slices; i++) {
			
			//Taking care of the spaces
			System.out.print("  ");
			for(int iClone=i; slices > iClone; iClone++) {
				System.out.print("   ");
			}
			//Printing the characters
			boolean reversed = false;
			if (i == 1) {System.out.print("1");}
			else
			for(int iClone2=i; iClone2 <= i;) {
				//Print the character, if its the last character don't do anything, else print two spaces
				System.out.print(iClone2);
				if (reversed && iClone2==i) {}
				else {System.out.print("  ");}
				
				//Increase the number being printed or decrease it depending on weather it passed the center of the pyramid
				if (iClone2==1) {reversed = true;}
				if (reversed) {iClone2++;}
				else {iClone2--;}
			}
		System.out.print("\n");	
		}
	}
}
