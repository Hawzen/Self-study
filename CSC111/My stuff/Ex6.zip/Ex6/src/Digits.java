import java.util.Scanner;
public class Digits {
	public static void main(String[] args) {
		System.out.print("Enter a number (-1 to end): ");
		Scanner input = new Scanner(System.in);
		while(true) {
			int nm = input.nextInt();
			String nmString = Integer.toString(nm);
			
			if (nm == -1 ) {break;}
			for (int i =1; i <= nmString.length(); i++) {
				System.out.println("Digit" + i + " = " + nmString.charAt(nmString.length() - i));
			}
			
		}
	}
}
