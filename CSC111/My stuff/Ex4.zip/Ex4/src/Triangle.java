import java.util.Scanner;
public class Triangle {
	public static void main(String[] args) {
		System.out.print("Enter three edges (length in double): ");
		Scanner input = new Scanner(System.in);
		
		double a = input.nextDouble();
		double b = input.nextDouble();
		double c = input.nextDouble();
		
		if (a+b>c && a+c>b && b+c>a ) {
			System.out.print("The perimeter is " + (a+b+c));
		}
		else {
			System.out.print("Input is invalid");
		}
	}
}
