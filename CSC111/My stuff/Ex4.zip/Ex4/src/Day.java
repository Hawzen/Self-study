import java.util.Scanner;
public class Day {
	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
		//Getting info from user
		System.out.print("Enter year: (e.g., 2012): "); int yr = input.nextInt();
		System.out.print("Enter month: 1-12: "); int mth = input.nextInt();
		System.out.print("Enter the day of the month: 1-31: "); int dy = input.nextInt();
		//Setting up info to use in formula
		String[] days = {"Saturday", "Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday"};
		if (mth == 1 || mth == 2) {mth += 12; yr-=1;}
		//formula and output
		System.out.print("Day of the week is " + 
		days[(dy + (26*(mth+1)/10) + yr%100 + (yr%100)/4 + (yr/100)/4 + 5*(yr/100))%7]);
	}
}
