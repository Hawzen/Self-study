import java.util.Scanner;
public class Divisible {
	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
		System.out.print("Enter and integer: "); 
		int x = input.nextInt();
		
		boolean[] div = new boolean[3];
		if (x%30==0) {
			div[0]= true;
			div[1]= true;
		}
		else if (x%5 == 0 || x%6 == 0) {
			div[1]= true;
			if(x%5 != 0 || x%6 != 0) {
				div[2] = true;
			}
		}
		System.out.println("Is " + x + " divisible by 5 and 6? " +div[0]);
		System.out.println("Is " + x + " divisible by 5 or 6? " +div[1]);
		System.out.println("Is " + x + " divisible by 5 or 6 but not both? " +div[2]);
	} 
}
