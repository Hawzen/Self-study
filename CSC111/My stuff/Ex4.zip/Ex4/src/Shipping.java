import java.util.Scanner;
public class Shipping {
	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
		
		System.out.print("Enter package weight: ");
		double wt = input.nextDouble();
		if (wt < 0 || wt > 20) {
			System.out.print("Nigga what u doin? invalid input is a not something to be toyed with!");
		}
		else if (wt <= 1) {
			wt = 3.5;
		}
		else if (wt <= 3) {
			wt = 5.5;
		}
		else if (wt <= 10) {
			wt = 8.5;
		}
		else {
			wt = 10.5;
		}
		System.out.print("The shipping cost is $" + wt);
	}
}
