import java.util.Scanner;
public class TestCafe {
	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
		
		double totalSale=0;
		
		Cafe c1 = new Cafe();
		c1.setCoffeePrice(5.50);c1.setTeaPrice(3.5);c1.setDonutPrice(2.25);c1.setDiscount(10);
		c1.setTeaTotQty(100);c1.setCoffeeTotQty(100);c1.setDonutTotQty(50);
		
		while(true) {
			System.out.print(
			"**********************************************************************\r\n" +
			"* Welcome to Cafe :) *\r\n" + 
			"* --------------------------- *\r\n" + 
			"* Please enter one of the following options: *\r\n" + 
			"* 1) order ==> this allows you to order a drink *\r\n" + 
			"* 2) quit ==> to end this program *\r\n" + 
			"* * \r\n"+
			"**********************************************************************\r\n" + 
			"Enter your option :> \r\n");
			if(input.nextInt()==2) {
				//Choice Quit
				System.out.print("Total sales = "+totalSale+"\r\n" + 
								 "Thanks, Goodbye!");
				break;}
			
			//Choice Continue
			System.out.print(
			"Please, enter order (#cups of coffee, #cups of tea and #donuts: \r\n");
			totalSale += c1.order(input.nextInt(), input.nextInt(), input.nextInt());
			
		}
	}
}
