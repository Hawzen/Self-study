public class Cafe {
	
	private int coffeeTotQty,	teaTotQty,	donutTotQty;
	private double coffeePrice, teaPrice, donutPrice, discount,	subtotal,	
					discountedPrice, total;
	private void calculateSubTotal(int	coffeeQty,	int	teaQty,	int	donutQty) {
		subtotal = coffeeQty*coffeePrice + teaQty*teaPrice + donutQty*donutPrice;
	}
	private void calculateTotal(int	coffeeQty,	int	teaQty,	int	donutQty) {
		calculateSubTotal(coffeeQty, teaQty, donutQty);
		discountedPrice = subtotal*discount*0.01;
		total = subtotal*(1-discount*0.01);
	}
	public double order(int	coffeeQty,	int	teaQty,	int	donutQty) {
		if(coffeeQty > coffeeTotQty || teaQty > teaTotQty || donutQty > donutTotQty) {
			System.out.print("Error: no enough cups and/or donuts");
			return 0;
		}
		calculateTotal(coffeeQty, teaQty, donutQty);
		display(coffeeQty, teaQty, donutQty);
		return total;
	}
	public void	display(int	coffeeQty,	int	teaQty,	int	donutQty) {
		System.out.print(
	"------------------------------------------------------------------\r\n" + 
	"Item		Quantity		Price\r\n" + 
	"------------------------------------------------------------------\r\n" + 
	"Coffee		"+coffeeQty+"			"+coffeeQty*coffeePrice+"\r\n" + 
	"Tea		"+teaQty+"			"+teaQty*teaPrice+"\r\n" + 
	"Donuts		"+donutQty+"			"+donutQty*donutPrice+"\r\n" + 
	"------------------------------------------------------------------\r\n" + 
	"Sub total				"+subtotal+"\r\n"+ 
	"discount		(%"+discount+")			"+discountedPrice+"\r\n"+ 
	"------------------------------------------------------------------\r\n" + 
	"Total						"+total+"\r\n" + 
	"");
	}
	
	
	
	
	
	
	
	
	
	
	public int getCoffeeTotQty() {
		return coffeeTotQty;
	}
	public void setCoffeeTotQty(int coffeeTotQty) {
		this.coffeeTotQty = coffeeTotQty;
	}
	public int getTeaTotQty() {
		return teaTotQty;
	}
	public void setTeaTotQty(int teaTotQty) {
		this.teaTotQty = teaTotQty;
	}
	public int getDonutTotQty() {
		return donutTotQty;
	}
	public void setDonutTotQty(int donutTotQty) {
		this.donutTotQty = donutTotQty;
	}
	public double getCoffeePrice() {
		return coffeePrice;
	}
	public void setCoffeePrice(double coffeePrice) {
		this.coffeePrice = coffeePrice;
	}
	public double getTeaPrice() {
		return teaPrice;
	}
	public void setTeaPrice(double teaPrice) {
		this.teaPrice = teaPrice;
	}
	public double getDonutPrice() {
		return donutPrice;
	}
	public void setDonutPrice(double donutPrice) {
		this.donutPrice = donutPrice;
	}
	public double getDiscount() {
		return discount;
	}
	public void setDiscount(double discount) {
		this.discount = discount;
	}
	public double getSubtotal() {
		return subtotal;
	}
	public double getDiscountedPrice() {
		return discountedPrice;
	}
	public double getTotal() {
		return total;
	}	
	
	
}
