import java.util.Scanner;
public class Fuel {
	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
		System.out.print("Enter the driving distance: "); double dst = input.nextDouble();
		System.out.print("Enter kilos per liter: "); double dstPerLt = input.nextDouble();
		System.out.print("Enter price per liter: "); double prcPerLt = input.nextDouble();
		
		System.out.print("The cost of driving is $" + ((dst/dstPerLt)*prcPerLt));
	}
}
