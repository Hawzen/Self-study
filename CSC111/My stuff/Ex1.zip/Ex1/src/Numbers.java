import java.util.Scanner;
public class Numbers {
public static void main(String[] args) {
	Scanner input = new Scanner(System.in);
	System.out.print("Enter three numbers: ");
	int a = input.nextInt(); int b = input.nextInt(); int c = input.nextInt(); 
	
	
	
	System.out.println("Sum = " + (a + b + c));
	System.out.println("Mult = " + (a*b*c));
	System.out.println("Avr = " + ((a+b+c)/3.0));
	System.out.println("pow = " + Math.pow(a, b));
}
}
