public class Library {

    private Book[] libraryBooks;
    private int numOfBooks=0;
    public static final int MAX_SIZE=100;

    public Library() {
        libraryBooks=new Book[MAX_SIZE];
        numOfBooks=0;
    }


    public boolean addBook(int ISBN,String author,String title,String genre) {
        Book ketab =new Book(ISBN,author,title,genre);

        if(ketab.verifyISBN(ISBN)) {
            if(findBook(ISBN)==-1) {
                libraryBooks[numOfBooks]=ketab;
                numOfBooks++;
                return true;
            }
            else
                return false;
        }
        return false;
    }


    public boolean addBook(Book ketab) {
        if(ketab.verifyISBN(ketab.getISBN())) {
            if(findBook(ketab)==-1) {
                libraryBooks[numOfBooks]=ketab;
                numOfBooks++;
                return true;
            }
            else
                return false;
        }
        else
            return false;
    }



    public void deleteBook(int ISBN) {

        for(int i=0;i<libraryBooks.length;i++) {
            if(libraryBooks[i]!=null)
                if(libraryBooks[i].getISBN()==ISBN) {

                    libraryBooks[i]=libraryBooks[numOfBooks];

                    libraryBooks[numOfBooks]=null;
                    numOfBooks--;}}
    }

    public int findBook(int ISBN) {
        if(libraryBooks[0]!=null) {

            for(int i=0;i<libraryBooks.length;i++) {
                if(libraryBooks[i]!=null)
                    if(libraryBooks[i].getISBN()==ISBN)
                        return i;}}

        return -1;
    }

    public int findBook(Book ketab) {
        for(int i=0;i<libraryBooks.length;i++)
            if(libraryBooks[i].equals(ketab))
                return i;

        return -1;
    }

    public void printAll() {
        for(int i=0;i<libraryBooks.length;i++)
            if(libraryBooks[i]!=null)
                libraryBooks[i].printBookInfo();
    }

    public void printGenre(String g) {
        for(int i=0;i<libraryBooks.length;i++) {
            if(libraryBooks[i]!=null)
                if(libraryBooks[i].getGenre().equalsIgnoreCase(g))
                    libraryBooks[i].printBookInfo();}
    }

    public int getNumberOfBooksByAuthor(String a) {
        int num=0;
        for(int i=0;i<libraryBooks.length;i++) {
            if(libraryBooks[i]!=null)
                if(libraryBooks[i].getAuthor().equalsIgnoreCase(a))
                    num++;}

        return num;
    }

    public int getNumberOfBooks() {
        return numOfBooks;
    }

    public Book[] getLibraryBooks() {
        return libraryBooks;
    }

    public void setNumOfBooks(int n) {
        numOfBooks=n;
    }





}
