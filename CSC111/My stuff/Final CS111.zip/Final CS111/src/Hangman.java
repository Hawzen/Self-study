import java.util.Scanner;
import java.util.Random;
public class Hangman {

    String[] words = {"give", "me", "full", "mark", "please"};
    char[] hiddenWord;
    char[] guessedWord;
    Scanner in = new Scanner(System.in);

    private int indexOf(char c) {
        for(int i = 0; i<hiddenWord.length; i++) {
            if (c == hiddenWord[i])
                return i;
        }
        return -1;
    }

    private void setCharAt(int i, char c, char[] arr) {
        arr[i] = c;
    }

    private String pickWord() {
        Random ran = new Random();
        return words[ran.nextInt(words.length)];
    }

    private char[] copyStringToArray(String s) {
        return s.toCharArray();
    }

    private void printWord() {
        System.out.print(new String(guessedWord));
    }

    private boolean isComplete() {
        for(char c : guessedWord) {
            if (c == '*') {
                return false;
            }
        }
        return true;
    }

    private void playOneRound() {
        Random ranAlot = new Random();
        hiddenWord = copyStringToArray(words[ranAlot.nextInt(words.length)]);
        guessedWord = new char[hiddenWord.length];
        for(int i = 0; i<guessedWord.length; i++) {
            guessedWord[i] = '*';
        }
        printWord();
        System.out.println( " > ");

        int misses = 0;
        while(true) {
            if (isComplete()) {
                System.out.print("The word is ");
                printWord();
                System.out.println(".\n You missed "+misses+ " time\\s.");
                break;
            }
            System.out.println("(Guess) Enter a letter in word " + new String(guessedWord) + " > ");
            int index = indexOf(in.next().toCharArray()[0]);
            if (index == -1) {
                System.out.println("Wrong");
                misses++;
            }
            else {
                setCharAt(index, hiddenWord[index], guessedWord);
                setCharAt(index,'$', hiddenWord);
            }
        }
    }

    public void play() {
        System.out.println("Welcome to Hang me game. Are you ready? OK, let me start tying the noose");
        while(true) {
            System.out.println("Do you want to play? (y/n)");
            if(in.next().equals("y")) {
                playOneRound();
            }
            else {
                System.out.println("GoodBye!");
                break;
            }
        }
    }

    public String[] getWords() {
        return words;
    }

    public char[]getHiddenWord(){
        return hiddenWord;
    }

}
