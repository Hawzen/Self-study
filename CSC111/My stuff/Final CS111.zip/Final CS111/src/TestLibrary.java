import java.util.Scanner;

public class TestLibrary {

    public static void main(String[] args) {
        Scanner in=new Scanner(System.in);
        int choice; Library libra=new Library();  int intTemp; String StringTemp;

        System.out.println("**********************************************************************");
        System.out.println("*		Welcome to KSU Library :)");
        System.out.println("*		---------------------------");

        do {
            System.out.println("*	 Please enter one of the following options:");
            System.out.println("*	1) Add a book");
            System.out.println("*	2) Delete a book");
            System.out.println("*	3) Find a book");
            System.out.println("*	4) List all books");
            System.out.println("*	5) List books for a given genre");
            System.out.println("*	6) Number of books for a give author");
            System.out.println("*	7) Total number of books");
            System.out.println("*	8) Exit");
            System.out.println("**********************************************************************");
            System.out.print("Enter option :> ");
            choice=in.nextInt();

            switch(choice) {

                case 1:
                    System.out.println("Please, enter the book details #ISBN, author, title, and genre");
                    if(libra.addBook(in.nextInt(), in.next() , in.next(), in.next() ) )
                        System.out.println("The book is added sucsesfully");
                    else
                        System.out.println("Error, check if book was already there before or you inserted a wrong ISBN");
                    break;

                case 2:
                    System.out.println("Please, enter the #ISBN number of the book that you wish to delete.");
                    libra.deleteBook(in.nextInt());
                    System.out.println("Done.");
                    break;

                case 3:
                    System.out.println("Please, enter #ISBN of the book you want.");
                    intTemp=in.nextInt();
                    if(libra.findBook(intTemp)==-1)
                        System.out.println("Book was not found");
                    else
                        System.out.println("Book number "+intTemp+" was found in index "+libra.findBook(intTemp));
                    break;

                case 4:
                    libra.printAll();
                    break;

                case 5:
                    System.out.println("Please, enter the genre you want.");
                    libra.printGenre(in.next());
                    break;

                case 6:
                    System.out.println("Please, enter the author name.");
                    StringTemp=in.next();

                    System.out.println("The author: "+StringTemp+" has "+libra.getNumberOfBooksByAuthor(StringTemp)+"  book/s");
                    break;

                case 7:
                    System.out.println("There are "+libra.getNumberOfBooks()+" book/s");
                    break;
            }


        }while(choice!=8);
        System.out.println("Thanks. Goodbye!");

    }
}




