
public class TestHangman {

    public static void main(String[] args) {
        (new Hangman()).play();;

    }

}
