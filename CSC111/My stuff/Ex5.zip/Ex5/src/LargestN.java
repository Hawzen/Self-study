
public class LargestN {
	public static void main(String[] args) {
		int n = (int) Math.pow(12000, 1D/3);
		System.out.print("This number is " + n);
	} 
}
