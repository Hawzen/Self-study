import java.util.Scanner;

public class Max {
	public static void main(String[] args) {
		String tempName; String name = "no one";
		double tempScore; double score = -1;
		Scanner input = new Scanner(System.in);
		
		System.out.print("Enter the number of students: ");
		int number = input.nextInt();
		
		while(number-->0) {
			System.out.print("Enter a student name: ");
			tempName = input.next();
			System.out.print("Enter a student score: ");
			tempScore = input.nextDouble();
			
			if (tempScore > score) {
				score = tempScore;
				name = tempName;
			}	
		}		
		System.out.print("Top student " + name + "'s score is " + score);
	}
}
