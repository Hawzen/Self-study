
public class Sort {

	public static void insertionSort(int[] A, int n) {
		for (int i = 1; i < n; i++) {
			int j = i;
			while (j > 0 && A[j - 1] > A[j]) {
				int tmp = A[j];
				A[j] = A[j - 1];
				A[j - 1] = tmp;
				j--;
			}
		}
	}

	public static void selectionSort(int[] A, int n) {
		for (int i = 0; i < n - 1; i++) {
			int min = i;
			for (int j = i + 1; j < n; j++) { // Search for the minimum
				if (A[j] < A[min])
					min = j;
			}
			// Swap A [ i ] with A [ min ]
			int tmp = A[i];
			A[i] = A[min];
			A[min] = tmp;
		}
	}

	public static void bubbleSort(int A[], int n) {
		for (int i = 0; i < n - 1; i++) {
			for (int j = 0; j < n - 1 - i; j++) {
				if (A[j] > A[j + 1]) {
					// Swap A [ j ] with A [ j +1]
					int tmp = A[j];
					A[j] = A[j + 1];
					A[j + 1] = tmp;
				}
			}
		}
	}

	public static void mergeSort(int[] A, int l, int r) {
		if (l >= r)
			return;
		int m = (l + r) / 2;
		mergeSort(A, l, m); // Sort first half
		mergeSort(A, m + 1, r); // Sort second half
		merge(A, l, m, r); // Merge
	}

	private static void merge(int[] A, int l, int m, int r) {
		int[] B = new int[r - l + 1];
		int i = l, j = m + 1, k = 0;
		while (i <= m && j <= r)
			if (A[i] <= A[j])
				B[k++] = A[i++];
			else
				B[k++] = A[j++];
		if (i > m)
			while (j <= r)
				B[k++] = A[j++];
		else
			while (i <= m)
				B[k++] = A[i++];
		for (k = 0; k < B.length; k++)
			A[k + l] = B[k];
	}

	public static void quickSort(int[] A, int l, int r) {
		if (l < r) {
			int s = partition(A, l, r);
			quickSort(A, l, s - 1);
			quickSort(A, s + 1, r);
		}
	}

	private static int partition(int[] A, int l, int r) {
		int p = A[l], i = l + 1, j = r;
		while (i < j) {
			while (A[i] <= p && i < j)
				i++;
			while (A[j] > p && i < j)
				j--;
			int tmp = A[i];
			A[i] = A[j];
			A[j] = tmp;
		}
		int s;
		if (A[i] <= p)
			s = i;
		else
			s = i - 1;
		int tmp = A[l];
		A[l] = A[s];
		A[s] = tmp;
		return s;
	}

	private static int max(int[] A, int n) {
		int max = A[0];
		for (int i = 1; i < n; i++) {
			if (A[i] > max) {
				max = A[i];
			}
		}
		return max;
	}

	private static int[] sort(List<Integer> l) {
		int[] B = new int[l.length()];
		if (!l.empty()) {
			int j = 0;
			while (l.length() > 0) {
				B[j++] = l.retrieve();
				l.remove();
			}
			insertionSort(B, B.length);
		}
		return B;
	}

	public static void bucketSort(int[] A, int n, int k) {
		@SuppressWarnings("unchecked")
		List<Integer>[] buckets = new List[k];
		for (int b = 0; b < k; b++) {
			buckets[b] = new LinkedList<Integer>();
		}
		int max = max(A, n);
		max++;
		for (int i = 0; i < n; i++) {
			buckets[k * A[i] / max].insert(A[i]);
		}
		int i = 0;
		for (int b = 0; b < k; b++) {
			int[] B = sort(buckets[b]);
			for (int j = 0; j < B.length; j++) {
				A[i++] = B[j];
			}
		}
	}

	private static int[] countingSortIndex(int[] A, int n, int m) {
		int[] counts = new int[m];
		for (int j = 0; j < m; j++) {
			counts[j] = 0;
		}
		for (int i = 0; i < n; i++) {
			counts[A[i]]++;
		}
		for (int j = 1; j < m; j++) {
			counts[j] += counts[j - 1];
		}
		int[] index = new int[n];
		for (int i = n - 1; i >= 0; i--) {
			index[i] = counts[A[i]] - 1;
			counts[A[i]]--;
		}
		return index;
	}

	public static void countingSort(int[] A, int n, int m) {
		int[] counts = new int[m];
		for (int j = 0; j < m; j++) {
			counts[j] = 0;
		}
		for (int i = 0; i < n; i++) {
			counts[A[i]]++;
		}
		for (int j = 1; j < m; j++) {
			counts[j] += counts[j - 1];
		}
		int[] B = new int[n];
		for (int i = n - 1; i >= 0; i--) {
			B[counts[A[i]] - 1] = A[i];
			counts[A[i]]--;
		}
		for (int i = 0; i < n; i++) {
			A[i] = B[i];
		}
	}

	public static void radixSort(int[] A, int n, int b) {
		int[] B = new int[n];
		int dv = 1;
		while (true) {
			boolean done = true;
			for (int i = 0; i < n; i++) {
				B[i] = (A[i] / dv) % b;
				if (B[i] != 0) {
					done = false;
				}
			}
			if (done) {
				break;
			}
			int[] index = countingSortIndex(B, n, b);
			for (int i = 0; i < n; i++) {
				B[index[i]] = A[i];
			}
			for (int i = 0; i < n; i++) {
				A[i] = B[i];
			}
			dv *= b;
		}
	}

	private static void print(int[] A, int n) {
		for (int i = 0; i < n; i++) {
			System.out.print(A[i] + " ");
		}
		System.out.println();
	}

	public static void main(String[] args) {
		{
			int[] A = { 12, 5, 8, 16, 9, 31 };
			insertionSort(A, A.length);
			print(A, A.length);
		}
		{
			int[] A = { 4, 5, 1, 4, 8, 3, 7 };
			selectionSort(A, A.length);
			print(A, A.length);
		}
		{
			int[] A = { 4, 5, 1, 4, 8, 3, 7 };
			bubbleSort(A, A.length);
			print(A, A.length);
		}
		{
			int[] A = { 4, 5, 1, 4, 8, 3, 7, 0 };
			mergeSort(A, 0, A.length - 1);
			print(A, A.length);
		}
		{
			int[] A = { 4, 5, 1, 4, 8, 3, 7, 0 };
			quickSort(A, 0, A.length - 1);
			print(A, A.length);
		}
		{
			int[] A = { 4, 25, 1, 18, 14, 29, 8, 7 };
			bucketSort(A, A.length, 3);
			print(A, A.length);
		}
		{
			int[] A = { 4, 5, 1, 4, 7, 3, 7, 0 };
			countingSort(A, A.length, 10);
			print(A, A.length);
		}
		{
			int[] A = { 54, 875, 21, 4, 418, 313, 253, 540, 21, 74 };
			radixSort(A, A.length, 10);
			print(A, A.length);
		}

	}

}
